<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/estilologin.css">
    <title>Cadastro - Aluno</title>
</head>
<body>
    <style>
        body{
    font-family: Arial, Helvetica, sans-serif;
    background-image: url('https://bkpsitecpsnew.blob.core.windows.net/uploadsitecps/sites/1/2020/10/etec-guaianazes-scaled.jpg');
    background-repeat: no-repeat;
    height:500px;
    background-position: center;
    background-size: cover;
}
.box{
    color: rgb(255, 255, 255);
    position: absolute;
    margin-left: 37.5%;
    margin-top: 10%;
    margin-bottom: 2%;
    background-color: rgba(0, 0, 0, 0.6);
    padding: 20px;
    border-radius: 15px;
    width: 20%;
    -ms-transform: translateY(-20%);
    transform: translateY(-20%);
}
fieldset{
    border: 3px solid rgb(255, 124, 124);
}
legend{
    border: 1px solid rgb(250, 226, 161);
    padding: 10px;
    text-align: center;
    background-color: rgb(112, 141, 236);
    border-radius: 8px;
}
.inputBox{
    position: relative;
    
}
.inputUser{
    background: none;
    border: none;
    border-bottom: 1px solid white;
    outline: none;
    color: white;
    font-size: 15px;
    width: 100%;
    letter-spacing: 2px;
}
.labelInput{
    position: absolute;
    top: 0px;
    left: 0px;
    pointer-events: none;
    transition: .5s;
}
.inputUser:focus ~ .labelInput,
.inputUser:valid ~ .labelInput{
    top: -20px;
    font-size: 12px;
    color: rgb(209, 89, 10);
}

#submit{
    background-color: rgb(112, 141, 236);
    width: 100%;
    border: none;
    padding: 15px;
    color: white;
    font-size: 15px;
    cursor: pointer;
    border-radius: 10px;
}
.SELECT{
    background-color: rgb(255, 124, 124) ;
    border-radius: 10px;
    width: 100%;
}



    </style>
    <div class="box">
        <form action="salvarCadastro.php" method="post">
            <fieldset>
                <h2>Se Cadastre</h2>
                <div class="inputBox">
                    <input type="text" name="txNome" id="txNome" class="inputUser" required>
                    <label class="labelInput">Nome completo</label>
                </div>
                <br><br>
                <div class="inputBox">
                    <input type="email" name="txEmail" id="txEmail" class="inputUser" required>
                    <label class="labelInput">Email</label>
                </div>
                <br><br>
                <div class="inputBox">
                    <input type="password" name="txSenha" id="txSenha" class="inputUser" required>
                    <label class="labelInput">Senha</label>
                </div>
                <br><br>
                <div class="inputBox">
                    <input type="date" name="txDataNasc" id="txDataNasc" class="inputUser" required>
                    <label class="labelInput">Data de Nascimento</label>
                </div>
                <br><br>
                <div class="inputBox">
                    <input type="text" name="txRg" id="txRg" class="inputUser" required>
                    <label class="labelInput">RG</label>
                </div>
                <br><br>
                <div class="inputBox">
                    <input type="text" name="txCpf" id="txCpf" class="inputUser" required>
                    <label class="labelInput">CPF</label>
                </div>
                <br><br>
                <div class="inputBox">
                    <label class="labelInput">Tipo de Entrada</label>
                    <br>
                    <select class="SELECT" name="txSelect" id="txSelect" required>
                        <option value="Aluno">Aluno</option>
                        <option value="Administrador">Administrador</option>
                    </select>
                </div>
                <br>
                <input type="submit" name="submit" id="submit" value="enviar"> 
            </fieldset>
        </form>
    </div>
</body>
</html>