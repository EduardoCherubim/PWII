<?php

    $x = $_GET['id'];

    echo $x;

    include("conexao.php");

    $stmt = $pdo->prepare("delete from tbaluno where idAluno='$x'");	
    $stmt ->execute();    

?>