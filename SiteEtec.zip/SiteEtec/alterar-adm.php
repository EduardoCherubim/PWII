<a href="apresentarAdm.php"><img src="images/seta.png" width="35px" id=voltar></a>
<section>
<center>
    <fieldset>
        <div class="box">
            <form action="adm-alterar.php" method="post">
                <legend><b>Fórmulario</b></legend> 
                <div class="inputbox">
                <input type="hidden" name="txIdAdm" value="<?php echo @$_GET['id']; ?>" />
                </div>
                <div class="inputbox">
                <input type="text" name="txNome" value="<?php echo @$_GET['nome']; ?>" placeholder="Nome" />
                    <label for="email">Nome</label>
                    <br><br>
                </div>
                <div class="inputbox">
                <input type="text" name="txEmail" value="<?php echo @$_GET['email']; ?>" placeholder="E-mail" />
                    <label for="CPF">E-mail</label>
                    <br><br>
                </div>
                <div class="inputbox">
                    <input type="text" name="txSenha" value="<?php echo @$_GET['senha']; ?>" placeholder="senha" />
                    <label for="RG">Senha</label>
                    <br><br>
                </div>
                <div class="inputbox">
                <input type="text" name="txRg" value="<?php echo @$_GET['rg']; ?>" placeholder="rg" />
                    <label for="RG">RG</label>
                    <br><br>
                </div>
                <div class="inputbox">
                <input type="text" name="txCpf" value="<?php echo @$_GET['cpf']; ?>" placeholder="cpf" />
                    <label for="RG">CPF</label>
                    <br><br>
                </div>
                <br><br>
                <button type="submit">mandar</button>
            </form>
        </div>
    </fieldset>
</center>