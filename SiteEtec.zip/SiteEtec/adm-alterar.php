<?php  
    $id = $_POST['txIdAdm'];
    $nome = $_POST['txNome'];
    $email = $_POST['txEmail'];
    $senha = $_POST['txSenha'];
    $rg = $_POST['txRg'];
    $cpf = $_POST['txCpf'];
    
    include("conexao.php");

    $stmt = $pdo->prepare("
        update tbadministrador set
            nomeAdm='$nome',
            emailAdm='$email',
            senhaAdm='$senha',
            rgAdm='$rg',
            cpfAdm='$cpf'
            where idAdm ='$id';
    ");	    
	$stmt ->execute();    

    header("location:apresentarAdm.php");    
    
?>