<?php  
    $id = $_POST['txIdAdm'];
    $nome = $_POST['txNome'];
    $email = $_POST['txEmail'];
    $senha = $_POST['txSenha'];
    $rg = $_POST['txRg'];
    $cpf = $_POST['txCpf'];
    
    include("conexao.php");

    $stmt = $pdo->prepare("
        update tbAdministrador set
            nome='$nome',
            email='$email',
            senha='$senha',
            rg='$rg'
            cpf='$cpf'
            where idAdm ='$id';
    ");	    
	$stmt ->execute();    

    header("location:consulta2.php");    
    
?>