<?php

    include("conexao.php");

    $comentario = $_POST['txComentario'];
    
    $stmt = $pdo->prepare("INSERT INTO tbcomentario (comentario) VALUES
     ('$comentario')");

    $stmt->execute();

    header("location:index.php");
    

?>

