<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contato</title>
    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
            text-align: center;
        }
        .box{
    color: rgb(255, 255, 255);
    position: absolute;
    margin-left: 55%;
    margin-top: 10%;
    margin-bottom: 2%;
    background-color: rgba(0, 0, 0, 0.6);
    padding: 20px;
    border-radius: 15px;
    width: 30%;
    -ms-transform: translateY(-20%);
    transform: translateY(-20%);
}
fieldset{
    border: 3px solid rgb(255, 124, 124);
}
legend{
    border: 1px solid rgb(250, 226, 161);
    padding: 10px;
    text-align: center;
    background-color: rgb(112, 141, 236);
    border-radius: 8px;
}
.inputBox{
    position: relative;
    
}
.inputUser{
    background: none;
    border: none;
    border-bottom: 1px solid white;
    outline: none;
    color: #E6E6E6;
    font-size: 15px;
    width: 100%;
    letter-spacing: 2px;
}
.labelInput{
    position: absolute;
    top: 0px;
    left: 0px;
    pointer-events: none;
    transition: .5s;
}
.inputUser:focus ~ .labelInput,
.inputUser:valid ~ .labelInput{
    top: -20px;
    font-size: 12px;
    color: #0B99E0;
}

#submit{
    background-color: #b20000;
    width: 100%;
    border: none;
    padding: 15px;
    color: #E6E6E6;
    font-size: 15px;
    cursor: pointer;
    border-radius: 10px;
}
.SELECT{
    background-color: rgb(255, 124, 124) ;
    border-radius: 10px;
    width: 100%;
}
.footer{
    position: relative;
      bottom: 0;
     width: 100%; 
    margin-top: 40%;
}
.mensagem{
    width: 100%;
    height: 200px;
    border-radius: 25px;
    background-color: #F2F2F2;
    resize: none;
}
.texto{
    margin-top: 4%;
    margin-left: 5%;
    border: 2px solid black;
    width: 600px;
    border-radius: 15px;
    padding-left: 15px;
}
.conteudo{
    font-size: 25px;
}
    </style>
    
</head>
<body>
        <?php include'header.php'?>
        <div class="box">
        <form action="salvarContato.php" method="post">
            <fieldset>
                <h2>Contate</h2>
                <br>
                <div class="inputBox">
                    <input type="text" name="txNome" id="txNome" class="inputUser" required>
                    <label class="labelInput">Nome completo</label>
                </div>
                <br><br>
                <div class="inputBox">
                    <input type="text" name="txEmail" id="txEmail" class="inputUser" required>
                    <label class="labelInput">Email</label>
                </div>
                <br>
                <div>
                    <br>
                <div class="inputBox">
                    <input type="text" name="txCpf" id="txCpf" class="inputUser" required>
                    <label class="labelInput">Assunto</label>
                </div>
                <br>
                <div>
                    <label class="etiqueta">Mensagem</label> <br>
                    <textarea class="mensagem" name="txMensagem"> </textarea>
                </div>
                <br>
                <input type="submit" name="submit" id="submit" value="Enviar"> 
            </fieldset>
        </form>
    </div>  
    
    <div class="texto">
        <h1 class="titulo">Contate-nos</h1>
        <br>
        <p class="conteudo">Nos mande um feedback sobre nosso projeto</p>
    </div>
        <div class="footer">
        <?php include('footer.php');?>
        </div>
        
</body>
</html>