<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contato</title>
    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
            text-align: center;
        }
        .box{
    color: rgb(255, 255, 255);
    position: absolute;
    margin-left: 37.5%;
    margin-top: 10%;
    margin-bottom: 2%;
    background-color: rgba(0, 0, 0, 0.6);
    padding: 20px;
    border-radius: 15px;
    width: 20%;
    -ms-transform: translateY(-20%);
    transform: translateY(-20%);
}
fieldset{
    border: 3px solid rgb(255, 124, 124);
}
legend{
    border: 1px solid rgb(250, 226, 161);
    padding: 10px;
    text-align: center;
    background-color: rgb(112, 141, 236);
    border-radius: 8px;
}
.inputBox{
    position: relative;
    
}
.inputUser{
    background: none;
    border: none;
    border-bottom: 1px solid white;
    outline: none;
    color: white;
    font-size: 15px;
    width: 100%;
    letter-spacing: 2px;
}
.labelInput{
    position: absolute;
    top: 0px;
    left: 0px;
    pointer-events: none;
    transition: .5s;
}
.inputUser:focus ~ .labelInput,
.inputUser:valid ~ .labelInput{
    top: -20px;
    font-size: 12px;
    color: #0B99E0;
}

#submit{
    background-color: rgb(112, 141, 236);
    width: 100%;
    border: none;
    padding: 15px;
    color: white;
    font-size: 15px;
    cursor: pointer;
    border-radius: 10px;
}
.SELECT{
    background-color: rgb(255, 124, 124) ;
    border-radius: 10px;
    width: 100%;
}
.footer{
    position: relative;
      bottom: 0;
     width: 100%; 
    margin-top: 40%;
}
textarea{
    width: 300px;
    height: 200px;
    border-radius: 5%;
}
    </style>
    
</head>
<body>
        <?php include'header.php'?>
        <div class="box">
        <form action="salvarContato.php" method="post">
            <fieldset>
                <h2>Contate</h2>
                <br>
                <div class="inputBox">
                    <input type="text" name="txNome" id="txNome" class="inputUser" required>
                    <label class="labelInput">Nome completo</label>
                </div>
                <br><br>
                <div class="inputBox">
                    <input type="text" name="txEmail" id="txEmail" class="inputUser" required>
                    <label class="labelInput">Email</label>
                </div>
                <br>
                <div>
                    <br>
                <div class="inputBox">
                    <input type="text" name="txCpf" id="txCpf" class="inputUser" required>
                    <label class="labelInput">Assunto</label>
                </div>
                <br>
                <div>
                    <label class="etiqueta">Mensagem</label> <br>
                    <textarea class="mensagem" name="txMensagem"> </textarea>
                </div>
                <br>
                <input type="submit" name="submit" id="submit" value="Enviar"> 
            </fieldset>
        </form>
    </div>  
    
        <div class="footer">
        <?php include('footer.php');?>
        </div>
        
</body>
</html>