<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contato</title>
    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
            text-align: center;
        }
       div {
            margin-top: 1%;
        }
        .mensagem{
            width: 90%;
            height: 150px;
        }
        .centro{
            padding-left: 35%;
            padding-right: 35%;
            position:relative;
            top: 30%;
            width: 100%;
        }
        .texto{
            width: 80%;
            border-radius: 15px;
        }
        .mensagem{
            border-radius: 7px;
        }
        .box{
            width: 100%;
            background-color: #d3d3d3;
            border-radius: 8%;
            border:2px solid black ;
        }
        .content-box{
            padding: 10%;          
        }
    </style>
    
</head>
<body>
        <?php include'header.php'?>

        <div class="centro">
            <div class="box">
                <div class="content-box">
                    <h3>Mande uma mensagem!</h3>

            <form action="salvarContato.php" method="post">
                <div>
                    <label class="etiqueta">Nome</label>
                    <input class="texto" type="text" name="txNome" />
                </div>

                <div>
                    <label class="etiqueta">E-mail</label>
                    <input class="texto" type="email" name="txEmail" />
                </div>

                <div>
                    <label class="etiqueta">Assunto</label>
                    <input class="texto" type="text" name="txAssunto" />
                </div>

                <div>
                    <label class="etiqueta">Mensagem</label> <br>
                    <textarea class="mensagem" name="txMensagem"> </textarea>
                </div>

                <div>
                    <input class="butao" type="submit" value="enviar">
                </div>
            </form>
            </div>
            </div>
        </div>

        <?php include('footer.php');?>
</body>
</html>