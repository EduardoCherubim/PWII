<?php
    include("conexao.php");
    
    $id = $_POST['txIdContato'];
    $nome = $_POST['txNome'];
    $email = $_POST['txEmail'];
    $assunto = $_POST['txAssunto'];
    $mensagem = $_POST['txMensagem'];

    $stmt = $pdo->prepare("
        UPDATE tbContato SET
            nome='$nome',
            email='$email',
            assunto='$assunto',
            mensagem='$mensagem'
            where idContato ='$id';
    ");

    $stmt -> execute();

    header("location:contatoAlterar.php");
?>