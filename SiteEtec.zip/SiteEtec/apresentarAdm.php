<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>
    <center>
    <table border="1" class="table">
        <tr>
            <th>id Administrador</th>
            <th>Nome Administrador</th>
            <th>E-mail Administrador</th>
            <th>Senha Administrador</th>
            <th>Rg Administrador</th>
            <th>Cpf Administrador</th>
        </tr>
        <?php
            include("conexao.php");

            $stmt = $pdo->prepare("select * from tbadministrador");
            $stmt -> execute();
            while($row = $stmt->fetch()){
                echo "
                <tr>
                   <td>".$row["idAdm"]."</td>
                   <td>".$row["nomeAdm"]."</td> 
                   <td>".$row["emailAdm"]."</td>
                   <td>".$row["senhaAdm"]."</td>
                   <td>".$row["rgAdm"]."</td>
                   <td>".$row["cpfAdm"]."</td>    
                </tr>";
            }

?>
    </table>
    </center>
</body>
</html>