<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/estilo.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body>
<a href="administrador.php"><img src="images/seta.png" width="35px" id=voltar></a>

<section>
        <form action="adm-alterar.php" method="post">      
            <div>
                <input type="hidden" name="txIdAdm" value="<?php echo @$_GET['id']; ?>" />
            </div>		

            <div>
                <input type="text" name="txNome" value="<?php echo @$_GET['nome']; ?>" placeholder="Nome" />
            </div>

            <div>
                <input type="text" name="txEmail" value="<?php echo @$_GET['email']; ?>" placeholder="E-mail" />
            </div>

            <div>
                <input type="text" name="txSenha" value="<?php echo @$_GET['senha']; ?>" placeholder="senha" />
            </div>

            <div>
                <input type="text" name="txRg" value="<?php echo @$_GET['rg']; ?>" placeholder="rg" />
            </div>

            <div>
                <input type="text" name="txCpf" value="<?php echo @$_GET['cpf']; ?>" placeholder="cpf" />
            </div>

            <div>
                <input type="submit" value="Salvar" />
            </div>
        </form>

    </section>
    <table class="table">
    <thead>
    <tr>
      <th scope="col">id</th>
      <th scope="col">nome</th>
      <th scope="col">email</th>
      <th scope="col">senha</th>
      <th scope="col">Rg</th>
      <th scope="col">Cpf</th>
    </tr>
  </thead>
  <tbody>
  <?php
            include("conexao.php");

            $stmt = $pdo->prepare("select * from tbadministrador");
            $stmt -> execute();
            while($row = $stmt->fetch()){

    ?>
    <tr>
      <th scope="row"><?php echo $row[0] ?></th>
      <td><?php echo $row[1] ?></td>
      <td><?php echo $row[2] ?></td>
      <td><?php echo $row[3] ?></td>
      <td><?php echo $row[4] ?></td>
      <td><?php echo $row[5] ?></td>
      <td>
         <a href="excluiradm.php?id=<?php echo $row[0]; ?>"> <img src="images/xsign.png" width="30px"> </a>
      </td>
      <td>
      <a href='<?php echo "?id=$row[0]&nome=$row[1]&email=$row[2]&senha=$row[3]&rg=$row[4]&cpf=$row[5]" ?>'>Editar</a>
      </td>
    </tr>

    <?php } ?>
  </tbody>
</table>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>