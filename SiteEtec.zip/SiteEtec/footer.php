<style>
  .rodape{
    margin-top: 10%;
  }
</style>
<footer width="120%" class="rodape">
  <div  class="text-bg-dark p-3">&copy; Todos os direitos reservados<br> Etec de Guaianazes -  R. gaspar dias de ataide, 290 - Guaianases, São Paulo</div>
</footer>
  