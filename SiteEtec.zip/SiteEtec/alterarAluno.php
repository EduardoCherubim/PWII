<?php
    include("conexao.php");

    $Id = $_POST['txIdAluno'];
    $nome = $_POST['txNome'];
    $email = $_POST['txEmail'];
    $senha = $_POST['txSenha'];
    $rg = $_POST['txRg'];
    $cpf = $_POST['txCpf'];

    $stmt = $pdo->prepare("
        UPDATE tbAluno SET
            nome = '$nome',
            email = '$email',
            senha = '$senha',
            rg = '$rg',
            cpf = '$cpf',
            WHERE idAluno = '$Id';
    ");

    $stmt -> execute();

    header("location:login.php");
?>