<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Etec Guaianazes</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="css/estilo.css">
    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
            text-align: center;
        }

        .container {
            justify-content: center;
            align-items: center;
            display: inline-flex;
        }

        .container1 {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            padding: 30px;
        }

        .texto {
            width: 45%;
            font-size: 22px;
        }

        .carrossel {
            width: 50%;
            text-align: center;
        }

        .carousel-inner {
            max-width: 1000px;
        }

        h1 {
            text-align: center;
        }

        .centro {
            text-align: center;
            padding-bottom: 40px;
            display: grid;
            place-items: center;
        }

        .nav-link {
            color: white;
        }

        .typing-demo {
            width: 35%;
            animation: typing 3s steps(30), blink .5s step-end infinite alternate;
            white-space: nowrap;
            overflow: hidden;
            border-right: 2px solid;
            font-family: Arial, Helvetica, sans-serif;
            font-size: 50px;
            font-weight: 700;
        }

        @keyframes typing {
            from {
                width: 0
            }
        }

        @keyframes blink {
            50% {
                border-color: transparent
            }
        }

        /* Inicio do código dos cards */

        /* A div do card em si: coloquei o tamanho e altura, esses podem ser ajustáveis a gosto.*/
        .flip-card {
            background-color: transparent;
            width: 300px;
            height: 200px;
            perspective: 1000px;
            /* Se não quiserem o efeito 3D, retirar apenas esse elemento */
        }

        /* Div para posicionar a parte de trás e de frente do card*/
        .flip-card-inner {
            position: relative;
            width: 100%;
            height: 100%;
            transition: transform 0.8s;
            transform-style: preserve-3d;
        }

        /* Faz a volta do card ao colocar o mouse sobre ele */
        .flip-card:hover .flip-card-inner {
            transform: rotateY(180deg);
        }

        /* Posição do lado de frente e do de trás */
        .flip-card-front,
        .flip-card-back {
            position: absolute;
            width: 100%;
            height: 100%;
            border-radius: 10px;
            box-shadow: 5px 5px 5px #888888;
            border: 1px solid;
            backface-visibility: hidden;
        }

        /* Estiliza a parte de frente do card */
        .flip-card-front {
            background-color: white;
            color: black;

        }

        /* Ajusta para o texto ficar centralizado no card */
        .flip-card-front-title {
            -ms-transform: translateY(300%);
            transform: translateY(300%);
        }

        /* Estilizar a parte de trás do card */
        .flip-card-back {
            background-color: white;
            color: black;
            transform: rotateY(180deg);
        }
    </style>
</head>

<body>
    <?php include('header.php');?>

    <div class="centro">
        <div class="typing-demo">
            Etec de Guaianazes
        </div>
        <br>

        <div class="container1">
            <div class="texto">
                <h2>Onde sua carreira começa de verdade!</h2>
                <p>Venha ser nosso aluno e estude gratuitamente em uma escola de qualidade, com ótima infraestrutura e
                    que te dará todo o suporte necessário para entrar no mercado de trabalho.</p>
            </div>

            <div class="carrossel">
                <div carousel-control-width="15%" id="carouselExampleCaptions" class="carousel slide"
                    data-bs-ride="carousel">
                    <div class="carousel-indicators">
                        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0"
                            class="active" aria-current="true" aria-label="Slide 1"></button>
                        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1"
                            aria-label="Slide 2"></button>
                        <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2"
                            aria-label="Slide 3"></button>
                    </div>
                    <div class="carousel-inner">
                        <div class="carousel-item active" hover="true" data-bs-interval="3000">
                            <img src="./images/foto1.jpg" class="d-block w-100" alt="...">
                            <div class="carousel-caption d-none d-md-block">
                            </div>
                        </div>
                        <div class="carousel-item" hover="true" data-bs-interval="3000">
                            <img src="./images/foto2.jpeg" class="d-block w-100" alt="...">
                            <div class="carousel-caption d-none d-md-block">
                            </div>
                        </div>
                        <div class="carousel-item" hover="true" data-bs-interval="3000">
                            <img src="./images/foto3.jpeg" class="d-block w-100" alt="...">
                            <div class="carousel-caption d-none d-md-block">
                            </div>
                        </div>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"
                        data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"
                        data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </button>
                </div>
            </div>
        </div>
        <br>
        <br>
        <br>
        <br>
        <div class="motivos">
            <h2>Motivos para estudar na Etec</h2>
            <br>
            <div class="container text-center">
                <div class="row">
                    <div class="col">
                        <div class="flip-card">
                            <div class="flip-card-inner">
                                <div class="flip-card-front">
                                    <h5>
                                        <p class="flip-card-front-title">Professores Qualificados</p>
                                    </h5>
                                </div>
                                <div class="flip-card-back">
                                    <br>
                                    <p class="card-text">Temos uma equipe de profissionais altamente capacitada para
                                        manter o nível de ensino em patamares elevados que, consequentemente, trazem
                                        excelentes resultados para o nossos alunos.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="flip-card">
                            <div class="flip-card-inner">
                                <div class="flip-card-front">
                                    <h5>
                                        <p class="flip-card-front-title">Ensino de Qualidade</p>
                                    </h5>
                                </div>
                                <div class="flip-card-back">
                                    <br>
                                    <p class="card-text">Estamos entre as melhores escolas públicas da região e nossa
                                        infraestrutura atende completamente às necessidades para uma formação de
                                        qualidade em qualquer um dos nossos cursos.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="flip-card">
                            <div class="flip-card-inner">
                                <div class="flip-card-front">
                                    <h5>
                                        <p class="flip-card-front-title">Competencias Transversais</p>
                                    </h5>
                                </div>
                                <div class="flip-card-back">
                                    <br>
                                    <p class="card-text">Por meio de projetos interdisciplinares, trabalhamos
                                        competências valiosas para o mercado de trabalho como a autogestão, resiliência,
                                        trabalho em equipe e inteligência emocional.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include'comentarios.php'?>
    <?php include'footer.php'?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
    </script>
</body>

</html>