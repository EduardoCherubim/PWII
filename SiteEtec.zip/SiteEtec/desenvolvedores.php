<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Desenvolvedores</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="css/estilo.css">
    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
            text-align: center;
        }

        h2 {
            text-align: left;
        }
        p{
            text-align: start;
            text-indent: 50px;
        }
        .image {
            border-radius: 20%;
            width: 250px;
            height: 250px;
        }
    </style>
</head>

<body>
    <?php include'header.php'?>

    <div class="container text-center">
        <p> <h1> Desenvolvedores da Página </h1></p>
         <br>   <br>
        <div class="container text-center">
            <div class="row">
                <div class="col-4">
                    <img class="image" src="images/imagem Carlos.jpeg">
                </div>
                 <div class="col-8">
                 <br> 
                 <h2> Carlos Alexandre </h2>
                 <p> Aluno da Etec de Guaianazes, cursando o 2º Ano do Ensino Médio junto do curso técnico em Desenvolvimento de Sistemas (DS). </p>
                </div>
            </div>
            <br> <br>
            <div class="row">
                <div class="col-4">
                    <img class="image" src="images/imagem Dudu.jpeg">
                </div>
                 <div class="col-8">
                 <br>
                 <h2> Eduardo Cherubim </h2>
                 <p> Aluno da Etec de Guaianazes, cursando o 2º Ano do Ensino Médio junto do curso técnico em Desenvolvimento de Sistemas (DS).</p>
                </div>
            </div>
            <br> <br>
            <div class="row">
                <div class="col-4">
                    <img class="image" src="images/imagem Kaue.jpeg">
                </div>
                 <div class="col-8">
                 <br>
                 <h2> Kaue Rodrigues </h2>
                 <p> Aluno da Etec de Guaianazes, cursando o 2º Ano do Ensino Médio junto do curso técnico em Desenvolvimento de Sistemas (DS).</p>
                </div>
            </div>
            <br> <br>
            <div class="row">
                <div class="col-4">
                    <img class="image" src="images/imagem Duarte.jpeg">
                </div>
                 <div class="col-8">
                    <br>
                    <h2> Leonardo Duarte </h2>
                    <p> Aluno da Etec de Guaianazes, cursando o 2º Ano do Ensino Médio junto do curso técnico em Desenvolvimento de Sistemas (DS).</p>
                </div>
            </div>
            <br> <br>
            <div class="row">
                <div class="col-4">
                    <img class="image" src="images/imagem viado.jpeg">
                </div>
                 <div class="col-8">
                 <br>
                  <h2>  Lucas Olyntho </h2>
                  <p> Aluno da Etec de Guaianazes, cursando o 2º Ano do Ensino Médio junto do curso técnico em Desenvolvimento de Sistemas (DS).</p>
                </div>
            </div>
        </div>   
    </div>

    <?php include'footer.php'?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>