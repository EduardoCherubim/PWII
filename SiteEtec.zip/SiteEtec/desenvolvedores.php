<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Desenvolvedores</title>
    <link rel="stylesheet" href="css/estilo.css">
    <style>
        .rowgrid1{
            display: grid;
            grid-template-columns:auto auto auto;
            row-gap: 50px;
            column-gap: 70px;
        }
        .rowgrid2{
            display:inline grid;
            grid-template-columns:auto auto;
            row-gap: 50px;
            column-gap: 70px;
        }
        body {
            font-family: Arial, Helvetica, sans-serif;
            text-align: center;
        }

        h1 {
            text-align: center;
        }

        .centro {
            text-align: center;
            padding-bottom: 40px;
        }

        .card {
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            transition: 0.3s;
            width: 60%;
        }

        .card:hover {
            box-shadow: 0 8px 16px 0 rgba(0, 0, 0, 0.2);
        }

        .container {
            padding: 2px 16px;
        }

        .nav-link {
            color: white;
        } 
         /* A div do card em si: coloquei o tamanho e altura, esses podem ser ajustáveis a gosto.*/
         .flip-card {
             background-color: transparent;
             width: 300px;
            height: 200px;
            perspective: 1000px; /* Se não quiserem o efeito 3D, retirar apenas esse elemento */
        }

        /* Div para posicionar a parte de trás e de frente do card*/
        .flip-card-inner {
            position: relative;
            width: 100%;
            height: 100%;
            transition: transform 0.8s;
            transform-style: preserve-3d;
        }

        /* Faz a volta do card ao colocar o mouse sobre ele */
        .flip-card:hover .flip-card-inner {
            transform: rotateY(180deg);
        }

        /* Posição do lado de frente e do de trás */
        .flip-card-front, .flip-card-back {
            position: absolute;
            width: 100%;
            height: 100%;
            border-radius: 10px;
            box-shadow: 5px 5px 5px #888888;
            border: 1px solid;
            backface-visibility: hidden;
        }

        /* Estiliza a parte de frente do card */
        .flip-card-front {
            background-color: white;
            color: black;
            
        }
        /* Ajusta para o texto ficar centralizado no card */
        .flip-card-front-title{
            -ms-transform: translateY(300%);
            transform: translateY(300%);
        }

        /* Estilizar a parte de trás do card */
        .flip-card-back {
            background-color: white;
            color: black;
            transform: rotateY(180deg);
        }
    </style>
</head>

<body>
    <?php include'header.php'?>

    <div class="container text-center">
        <p> <h1> Desenvolvedores da Página </h1></p>
        <br>
        <div class="rowgrid1">
            <div class="col">
                <div class="flip-card">
                <div class="flip-card-inner">
                    <div class="flip-card-front">
                    <img src="./images/etec-identidade.png" width="100%" height="100%">
                    </div>
                    <div class="flip-card-back">
                    <br>
                    <h4><b>Eduardo Cherubim</b></h4>
                    <p>Estudante Escola Técnica Estadual de Guaianazes, Cursando Desenvolvimento de Sistemas</p>
                    </div>
                </div>
            </div>
            </div>
            <div class="col">
            <div class="flip-card">
                <div class="flip-card-inner">
                    <div class="flip-card-front">
                    <img src="./images/etec-identidade.png" width="100%" height="100%">
                    </div>
                    <div class="flip-card-back">
                    <br>
                    <h4><b>Lucas Olyntho </b></h4>
                    <p>Estudante Escola Técnica Estadual de Guaianazes, Cursando Desenvolvimento de Sistemas</p>
                    </div>
                </div>
            </div>
            </div>
            <div class="col">
               <div class="flip-card">
                <div class="flip-card-inner">
                    <div class="flip-card-front">
                    <img src="./images/etec-identidade.png" width="100%" height="100%">
                    </div>
                    <div class="flip-card-back">
                    <br>
                    <h4><b>Carlos Alexandre</b></h4>
                    <p>Estudante Escola Técnica Estadual de Guaianazes, Cursando Desenvolvimento de Sistemas</p>
                    </div>
                </div>
            </div>
            </div>
        </div>
        <br>
            <div class="rowgrid2">
            <div class="col">
            <div class="flip-card">
                <div class="flip-card-inner">
                    <div class="flip-card-front">
                    <img src="./images/etec-identidade.png" width="100%" height="100%">
                    </div>
                    <div class="flip-card-back">
                    <br>
                    <h4><b>Kaue Rodrigues</b></h4>
                    <p>Estudante Escola Técnica Estadual de Guaianazes, Cursando Desenvolvimento de Sistemas</p>
                    </div>
                </div>
            </div>
            </div>
            <div class="col">
            <div class="flip-card">
                <div class="flip-card-inner">
                    <div class="flip-card-front">
                    <img src="./images/etec-identidade.png" width="100%" height="100%">
                    </div>
                    <div class="flip-card-back">
                    <br>
                    <h4><b>Leonardo Duarte</b></h4>
                    <p>Estudante Escola Técnica Estadual de Guaianazes, Cursando Desenvolvimento de Sistemas</p>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </div>

    <?php include'footer.php'?>
</body>

</html>