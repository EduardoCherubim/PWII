<?php

    $excluir = $_GET['id'];

    echo $excluir;

    include("conexao.php");

    $stmt = $pdo->prepare("delete from tbcontato where idContato='$excluir'");	
    $stmt ->execute();    

?>