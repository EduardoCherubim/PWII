<?php

    $x = $_GET['id'];

    echo $x;

    include("conexao.php");

    $stmt = $pdo->prepare("delete from tbadministrador where idAdm='$x'");	
    $stmt ->execute();    

?>