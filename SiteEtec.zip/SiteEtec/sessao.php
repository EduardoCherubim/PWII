<?php 
session_start();

include("conexao.php");

if (isset($_POST['btVisitante'])) {
    $visitante = $_POST['btVisitante'];
    if ($visitante == "true") {
        $_SESSION['nivel'] = "visitante";
    }
} else {
    $_SESSION['usuario'] = $_POST['txEmail'];
    $_SESSION['senha'] = $_POST['txSenha'];

    if (isset($_SESSION['usuario']) && isset($_SESSION['senha'])) {
        $stmt = $pdo->prepare("SELECT emailAluno FROM tbaluno WHERE emailAluno LIKE :email");
        $stmt->bindParam(':email', $_POST['txEmail']);
        $stmt->execute();
        $emailAluno = $stmt->fetchColumn();

        $stmt = $pdo->prepare("SELECT senhaAluno FROM tbaluno WHERE senhaAluno LIKE :senha");
        $stmt->bindParam(':senha', $_POST['txSenha']);
        $stmt->execute();
        $senhaAluno = $stmt->fetchColumn(); 

        $stmt = $pdo->prepare("SELECT emailAdm FROM tbadministrador WHERE emailAdm LIKE :email");
        $stmt->bindParam(':email', $_POST['txEmail']);
        $stmt->execute();
        $emailAdm = $stmt->fetchColumn(); 

        $stmt = $pdo->prepare("SELECT senhaAdm FROM tbadministrador WHERE senhaAdm LIKE :senha");
        $stmt->bindParam(':senha', $_POST['txSenha']);
        $stmt->execute();
        $senhaAdm = $stmt->fetchColumn(); 

        if ($_SESSION['usuario'] == $emailAluno && $_SESSION['senha'] == $senhaAluno) {
            $_SESSION['nivel'] = "Aluno";
        }
        elseif ($_SESSION['usuario'] == $emailAdm && $_SESSION['senha'] == $senhaAdm) {
            $_SESSION['nivel'] = "Adm";
        } 
        else {
            echo "Usuário/Adm inválido ou não existe";
        }
    }
}

header("location:index.php");

?>
