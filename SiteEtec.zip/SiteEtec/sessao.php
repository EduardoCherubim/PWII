<?php 
session_start();

include("conexao.php");

$_SESSION['usuario'] = $_POST['txEmail'];
$_SESSION['senha'] = $_POST['txSenha'];

$stmt = $pdo->prepare("select emailAluno from tbaluno where emailAluno Like".$_POST['txEmail']);
$emailAluno = $stmt -> execute();
$stmt = $pdo->prepare("select senhaAluno from tbaluno where senhaAluno Like".$_POST['txSenha']);
$senhaAluno = $stmt -> execute();

$stmt = $pdo->prepare("select emailAdm from tbadministrador where emailAdm Like".$_POST['txEmail']);
$emailAdm = $stmt -> execute();
$stmt = $pdo->prepare("select senhaAdm from tbadministrador where senhaAdm Like".$_POST['txSenha']);
$senhaAdm = $stmt -> execute();

if ($_SESSION['usuario'] == $emailAluno && $_SESSION['senha'] == $senhaAluno) {
    $_SESSION['nivel'] = "Aluno";
}elseif ($_SESSION['usuario'] == $emailAdm && $_SESSION['senha'] == $senhaAdm) {
    $_SESSION['nivel'] = "Adm";
}else{
    echo "Usúario/Adm não existe";
}
?>