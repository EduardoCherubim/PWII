<?php 
    include("conexao.php");

    $Id = $_POST['txIdNoticia'];
    $titulo = $_POST['txTitulo'];
    $subtitulo = $_POST['txSubtitulo'];
    $descricao = $_POST['txDescricao'];

    $stmt = $pdo->prepare("
    
            UPDATE tbaviso SET
                    titulo = '$titulo',
                    subtitulo = '$subtitulo',
                    descricao = '$descricao'
                    WHERE idNoticia = '$Id';
            ");

    $stmt -> execute();

    header("location:criarnoticia.php");
?>