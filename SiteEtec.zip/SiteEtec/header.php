<?php session_start();
?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
  integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<style>
  .nav-link {
    color: #E6E6E6;
    border-radius: 50px;
    margin: 10px;
  }

  .nav-link:hover{
    background-color: #900000 ;
    color: #E6E6E6;
  }

  .entrar {
    color: white;
    position: absolute;
    margin-left: 75%;
    margin-top: 3%
  }
</style>
<header style="background-color:#d3d3d3">
  <img src="./images/etec.png" style="width: 240px;">
  <?php 
  if (!isset( $_SESSION['nivel'])) {
    $_SESSION['nivel']="null";
  }
  if ($_SESSION['nivel'] == "Aluno" || $_SESSION['nivel'] == "Adm") {
    echo "";
  }else{
    echo "<a class='entrar' href='login.php'><button type='button' class='btn btn-secondary'>ENTRAR</button><a>";
  }
  ?>

</header>
<nav style="background-color: #b20000;">
  <ul class="nav">
    <li class="nav-item">
      <a class="nav-link" href="index.php">Home</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="contato.php">Contato</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="desenvolvedores.php">Desenvolvedores</a>
    </li>
    <?php
    if ($_SESSION['nivel'] == "Aluno") {
      echo "<li class='nav-item'>
      <a class='nav-link' href='painel.php'>Noticias</a>
    </li>";
    }elseif ($_SESSION['nivel'] == "Adm") {
      echo "<li class='nav-item'>
      <a class='nav-link' href='painel.php'>Noticias</a>
    </li>
    <li class='nav-item'>
      <a class='nav-link' href='administrador.php'>Administrador</a>
    </li>";
    }
    ?>
  </ul>
</nav>

<br>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
  integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>