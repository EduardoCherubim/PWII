<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/estilo.css">
    <link rel="stylesheet" href="./css/styletable.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>
<a href="administrador.php"><img src="images/seta.png" width="35px" id=voltar></a>

<h1 class="tituloadm">Comentários</h1>

<table class="table">
    <thead>
    <tr class="cabeca">
      <th class="titulo"  scope="col">id</th>
      <th class="titulo"  scope="col">comentarios</th>
      <th class="titulo" scope="col">Del</th>
      <th class="titulo" scope="col">Edit</th>
    </tr>
  </thead>
  <tbody>
  <?php
            include("conexao.php");

            $stmt = $pdo->prepare("select * from tbcomentario");
            $stmt -> execute();
            while($row = $stmt->fetch(PDO::FETCH_BOTH)){

    ?>
    <tr class="dados">
      <th class="info" scope="row"><?php echo $row[0] ?></th>
      <td class="info"><?php echo $row[1] ?></td>
      <td class="info">
        <a href="excluircomentario.php?id=<?php echo $row[0]; ?>"> <img src="images/xsign.png" width="30px"> </a> 
      </td>
      <td class="info">
      <a href="alterar-comentario.php?<?php echo "id=$row[0]&comentarios=$row[1]" ?>"> <img src="images/edit-button.png" width="35px"></a>
      </td> 
    </tr>

    <?php } ?>
  </tbody>
</table>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>