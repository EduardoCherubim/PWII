<a href="apresentarComentarios.php"><img src="images/seta.png" width="35px" id=voltar></a>
<section>
<center>
    <fieldset>
        <div class="box">
            <form action="comentario-alterar.php" method="post">
                <legend><b>Fórmulario</b></legend> 
                <div class="inputbox">
                <input type="hidden" name="txIdComentario" value="<?php echo @$_GET['id']; ?>" />
                </div>
                <div class="inputbox">
                <input type="text" name="txComentarios" value="<?php echo @$_GET['comentarios']; ?>" placeholder="Comentarios" />
                    <label for="email">Nome</label>
                    <br><br>
                </div>
                <br><br>
                <button type="submit">mandar</button>
            </form>
        </div>
    </fieldset>
</center>