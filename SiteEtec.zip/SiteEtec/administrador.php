<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/estilo.css">
    <title>Administrador</title>
</head>
<body>
    <style>
        .container-grid{
            display: grid;
            grid-template-columns: auto auto auto;
            row-gap: 50px;
            column-gap: 10px;
        }
        .button{
            display: inline-block;
            background-color: blue;
            color: black;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            border-radius: 5px;
            border: none;
            cursor: pointer;
        }
    </style>
    <h1> Administrador </h1>
    <div class="container-grid">
    <a href="bd/apresentarContato.php" class="button">Apresentar Contatos</a>
    <a href="bd/apresentarAluno.php" class="button">Apresentar Alunos</a>
    <a href="bd/apresentaAdm.php" class="button">Apresentar Administradores</a>
    <input type="submit" name="submit" id="submit" value="Registro 4"> 
    <input type="submit" name="submit" id="submit" value="Registro 5"> 
    <input type="submit" name="submit" id="submit" value="Registro 6"> 
    </div>
</body>
</html>