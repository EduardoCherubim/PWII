<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/estilo.css">
    <title>Administrador</title>
    <link rel="stylesheet" href="css/styleAdministrador.css">
    <style>
        
.container-grid{
    display: grid;
    grid-template-columns:auto auto;
    row-gap: 50px;
    column-gap: 70px;
   
}
        .button{
            display: inline-block;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            border:  1px solid;
            cursor: pointer;
            width: 100px;
            height: 50px;
            background-color: rgb(122, 153, 137);
            border-radius: 5%;
            color: rgb(255, 255, 255);
            margin-right: 15px;
            margin-left: -30px;

        }
        
.box{
    color: white;
    position: absolute;
    margin-left: 31.5%;
    margin-top: 8%;
    margin-bottom: 2%;
    background-color: rgba(100, 115, 146, 0.541);
    padding: 110px;
    border-radius: 15px;
    width: 20%;


}



    </style>
</head>

<body>

<a href="index.php"><img src="images/seta.png" width="35px" id=voltar></a>

    <div class=box>
    <div class="container-grid">
    <a href="apresentarContato.php" class="button"><b>Apresentar Contato</b></a>
    <a href="apresentarAluno.php" class="button"><b>Apresentar Aluno</b></a>
    <a href="apresentarAdm.php" class="button"><b>Apresentar Administrador</b></a>
    <a href="apresentarComentarios.php" class="button"><b>Apresentar Comentarios</b></a> 
    </div>
    </div>
</body>
</html>