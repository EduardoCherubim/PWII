<?php
    include("conexao.php");

    $nome = $_POST['txNome'];
    $email = $_POST['txEmail'];
    $senha = $_POST['txSenha'];
    $rg = $_POST['txRg'];
    $cpf = $_POST['txCpf'];

    $stmt = $pdo->prepare("
        INSERT INTO tbAluno values(
        
            null,
            '$nome',
            '$email',
            '$senha',
            '$rg',
            '$cpf'
        )
    ");

    $stmt -> execute();

    header("location:login.php");
?>