<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel</title>

    <style>
        .container-grid{
            display: grid;
            grid-template-columns: auto auto;
            row-gap: 20%;
            column-gap: 20%;
            justify-content: center;
            -ms-transform: translateY(60%);
            transform: translateY(60%);
            
            ;
        }
        .card {
            box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
             border-radius: 10px;
             width: 130%;
            }

        .card:hover {
            box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
            }
        .margin {
            position:relative;
            width: 100%;
            bottom: 0;
           
        }
        .link{
          display: block;
          margin-top: 15%;
          text-align: center;
        }
        .butao{
          border: none;
          padding: 16px 32px;
          text-align: center;
          text-decoration: none;
          display: inline-block;
          font-size: 16px;
          margin: 4px 2px;
          transition-duration: 0.4s;
          cursor: pointer;
        }
        .butaonoticia {
         background-color: white; 
          color: black; 
          border: 2px solid #EF372A;
        }

        .butaonoticia:hover {
        background-color: #F30B00;
        color: white;
        }
</style>

</head>
<body>
<?php include('header.php');?>

<div class="container-grid">
  <?php
    include("conexao.php");

    $stmt = $pdo->prepare("select * from tbaviso");
    $stmt -> execute();
    while($row = $stmt->fetch()){
        echo "<div class='card'>
                <div class='container'>
                  <h4><b>".$row["tituloAviso"]."</b></h4> 
                  <p>".$row["subtituloAviso"]."</p> 
                </div>
              </div>";
    }

  ?>
</div>

<div>
  <a class="link" href="./criarnoticia.php"> <button class="butao butaonoticia" type="button" value="">Inserir Noticia</button> </a> 
</div>

<div class="margin">
<?php include'footer.php'?>
</div>


</body>
</html>