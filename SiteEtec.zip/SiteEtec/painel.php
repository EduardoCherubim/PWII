<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel</title>

    <style>
        .container-grid{
            display: grid;
            grid-template-columns: auto auto auto;
            row-gap: 20%;
            column-gap: 20%;
            justify-content: center;
            -ms-transform: translateY(30%);
            transform: translateY(30%);
            
            ;
        }
        .card {
            box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
             border-radius: 10px;
             width: 130%;
            }

        .card:hover {
            box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
            }
        .margin {
            position:relative;
            width: 100%;
            bottom: 0;
           
        }
        .link{
          display: block;
          margin-top: 15%;
          text-align: center;
        }
        .butao{
          border: none;
          padding: 16px 32px;
          text-align: center;
          text-decoration: none;
          display: inline-block;
          font-size: 16px;
          margin-bottom: 2%;
          margin-top: 10%;
          transition-duration: 0.4s;
          cursor: pointer;
        }
        .butaonoticia {
         background-color: white; 
          color: black; 
          border: 2px solid #EF372A;
        }

        .butaonoticia:hover {
        background-color: #F30B00;
        color: white;
        }
</style>

</head>
<body>
<?php include('header.php');?>

<div class="container-grid">
  <?php
    include("conexao.php");

    $stmt = $pdo->prepare("select * from tbaviso");
    $stmt -> execute();
    while($row = $stmt->fetch(PDO::FETCH_BOTH)){
      ?>

          <div class="card">
                <div class="container">
                  <h3><b><?php echo $row[1];?></b></h3> 
                  <h5><?php echo $row[2];?></h5> 
                  <p><?php echo $row[3];?></p>
                 <a href="excluirnoticia.php?id=<?php echo $row[0];?>"> <img src="images/xsign.png" width="30px"> </a>
                 <a href="alterar-noticia.php?<?php echo "id=$row[0]&titulo=$row[1]&subtitulo=$row[2]&descricao=$row[3]" ?>">Editar</a>
                </div>
              </div>

    <?php } ?>

</div>

<div>
  <a class="link" href="./criarnoticia.php"> <button class="butao butaonoticia" type="button" value="">Inserir Noticia</button> </a> 
</div>

<div class="margin">
<?php include'footer.php'?>
</div>


</body>
</html>