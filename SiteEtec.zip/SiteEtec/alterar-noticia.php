<a href="painel.php"><img src="images/seta.png" width="35px" id=voltar></a>
<section>
<center>
    <fieldset>
        <div class="box">
            <form action="noticia-alterar.php" method="post">
                <legend><b>Fórmulario</b></legend> 
                <div class="inputbox">
                <input type="hidden" name="txIdAviso" value="<?php echo @$_GET['id']; ?>" />
                </div>
                <div class="inputbox">
                <input type="text" name="txTitulo" value="<?php echo @$_GET['titulo']; ?>" placeholder="Titulo" />
                    <label for="email">Nome</label>
                    <br><br>
                </div>
                <div class="inputbox">
                <input type="text" name="txSubtitulo" value="<?php echo @$_GET['subtitulo']; ?>" placeholder="Subtitulo" />
                    <label for="CPF">E-mail</label>
                    <br><br>
                </div>
                <div class="inputbox">
                <input type="text" name="txDesc" value="<?php echo @$_GET['descricao']; ?>" placeholder="Descrição" />
                    <label for="RG">Assunto</label>
                    <br><br>
                </div>
                <br><br>
                <button type="submit">mandar</button>
            </form>
        </div>
    </fieldset>
</center>
