<section>
        <form action="noticia-alterar.php" method="post">      
            <div>
                <input type="hidden" name="txIdAviso" value="<?php echo @$_GET['id']; ?>" />
            </div>		

            <div>
                <input type="text" name="txTitulo" value="<?php echo @$_GET['titulo']; ?>" placeholder="Titulo" />
            </div>

            <div>
                <input type="text" name="txSubtitulo" value="<?php echo @$_GET['subtitulo']; ?>" placeholder="Subtitulo" />
            </div>

            <div>
                <input type="text" name="txDesc" value="<?php echo @$_GET['descricao']; ?>" placeholder="Descrição" />
            </div>

            <div>
                <input type="submit" value="Salvar" />
            </div>
        </form>

    </section>