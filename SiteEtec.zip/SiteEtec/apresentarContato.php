<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>
    <center>
    <table border="1" class="table">
        <tr>
            <th>id Contato</th>
            <th>E-mail Contato</th>
            <th>Assunto Contato</th>
            <th>Mensagem Contato</th>
        </tr>
        <?php
            include("conexao.php");

            $stmt = $pdo->prepare("select * from tbcontato");
            $stmt -> execute();
            while($row = $stmt->fetch()){
                echo "
                <tr>
                   <td>".$row["idContato"]."</td>
                   <td>".$row["emailContato"]."</td>
                   <td>".$row["assuntoContato"]."</td>
                   <td>".$row["mensagemContato"]."</td>   
                </tr>";
            }

?>
    </table>
    </center>
</body>
</html>