<?php  
    $id = $_POST['txIdAluno'];
    $nome = $_POST['txNome'];
    $email = $_POST['txEmail'];
    $senha = $_POST['txSenha'];
    $rg = $_POST['txRg'];
    $cpf = $_POST['txCpf'];
    
    include("conexao.php");

    $stmt = $pdo->prepare("
        update tbaluno set
            nomeAluno='$nome',
            emailAluno='$email',
            senhaAluno='$senha',
            rgAluno='$rg',
            cpfAluno='$cpf'
            where idAluno ='$id';
    ");	    
	$stmt ->execute();    

    header("location:apresentarAluno.php");    
    
?>