<?php  
    $id = $_POST['txIdAluno'];
    $nome = $_POST['txNome'];
    $email = $_POST['txEmail'];
    $senha = $_POST['txSenha'];
    $rg = $_POST['txRg'];
    $cpf = $_POST['txCpf'];
    
    include("conexao.php");

    $stmt = $pdo->prepare("
        update tbAluno set
            nome='$nome',
            email='$email',
            senha='$senha',
            rg='$rg'
            cpf='$cpf'
            where idAluno ='$id';
    ");	    
	$stmt ->execute();    

    header("location:consulta2.php");    
    
?>