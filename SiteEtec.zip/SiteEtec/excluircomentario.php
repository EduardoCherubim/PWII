<?php

    $x = $_GET['id'];

    echo $x;

    include("conexao.php");

    $stmt = $pdo->prepare("delete from tbcomentario where idComentario='$x'");	
    $stmt ->execute();    

?>