<?php  
    $id = $_POST['txIdAviso'];
    $titulo = $_POST['txTitulo'];
    $subtitulo = $_POST['txSubtitulo'];
    $desc = $_POST['txDesc'];
    
    include("conexao.php");

    $stmt = $pdo->prepare("
        update tbaviso set
            tituloAviso='$titulo',
            subtituloAviso='$subtitulo',
            descAviso='$desc'
            where idAviso ='$id';
    ");	    
	$stmt ->execute();    

    header("location:painel.php");    
    
?>