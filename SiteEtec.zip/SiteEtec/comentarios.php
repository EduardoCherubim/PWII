
<center>

<div class="boxcoment">
        <form class="formcoment" action="comentar.php" method="post">
            <fieldset>

            <div>
            <label class="titleCom">Comente👇</label> <br>
            <textarea id="txComentario" name="txComentario" rows="8" cols="60"> </textarea>
        </div>

        <div class="divbotao">
            <input class="botao" type="submit" value="Enviar" />
        </div>

         
            </fieldset>
        </form>
    </div>

</center>