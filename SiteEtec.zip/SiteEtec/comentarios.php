<center>
    <Style>
        label {

            font-family: 'Bitter', serif;
            font-size: 1rem;
            font-weight: 200;
            letter-spacing: 0.025rem;
            font-style: normal;
            text-transform: capitalize;
            color: #FFFFFF;
            background-color: #DB605B;
            border-radius: 0.15rem;
            -webkit-border-radius: 0.15rem;
            -moz-border-radius: 0.15rem;
            padding: 0.3rem 0.4rem;
            border-style: outset;
            border-width: 0.3125rem;
            border-color: #000000;
            box-shadow: 13px 12px 21px 1px rgba(51, 51, 51, 0.27);
        }

        textarea {
            border: 5px outset #000000;
            border-radius: 15px;
        }

        .comentarios {
            border: 3px solid black;
            width: 40%;
            height: 300px;
            margin-bottom: -5%;
            align-content: flex-start;
            justify-items: flex-start;
            padding: 5px;
            padding-left: 10px;
            border-radius: 15px;
        }

        p {
            font-size: 18px;

        }
    </Style>
    <div class="boxcoment">
        <form class="formcoment" action="comentar.php" method="post">
            <fieldset>

                <div>
                    <label class="titleCom">Comente👇</label> <br> <br>
                    <textarea id="txComentario" name="txComentario" rows="8" cols="60"> </textarea>
                </div>

                <div class="divbotao">
                    <input class="botao" type="submit" value="Enviar" />
                </div>
            </fieldset>
        </form>
    </div>
    <br>
    <br>
    <div class="comentarios">
        <h4>Comentários</h4>
        <?php
            include("conexao.php");

            $stmt = $pdo->prepare("select * from tbcomentario");
            $stmt -> execute();
            while($row = $stmt->fetch(PDO::FETCH_BOTH)){

    ?>

        <p><?php echo $row[1] ?></p>
        <?php }?>
    </div>

</center>