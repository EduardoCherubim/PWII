<?php
    include("conexao.php");

    $nome = $_POST['txNome'];
    $email = $_POST['txEmail'];
    $senha = $_POST['txSenha'];
    $nasc = $_POST['txDataNasc'];
    $rg = $_POST['txRg'];
    $cpf = $_POST['txCpf'];

    $stmt = $pdo->prepare("

        insert into tbAluno values(
            null,
            '$nome',
            '$email',
            '$senha',
            '$nasc',
            '$rg',
            '$cpf'
        )
    ");

    $stmt -> execute();

    header("location:login.php");
?>