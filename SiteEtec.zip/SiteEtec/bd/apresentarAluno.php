<?php
    include("conexao.php");

    $nome = $_POST['txNome'];
    $email = $_POST['txEmail'];
    $senha = $_POST['txSenha'];
    $nasc = $_POST['txDataNasc'];
    $rg = $_POST['txRg'];
    $cpf = $_POST['txCpf'];

    $stmt = $pdo->prepare("select * from tbAluno)");
    while($raw = $stmt->fetch()){
        echo "Id Aluno". $row["idAluno"];
        echo "Nome Aluno". $row["nomeAluno"];
        echo "E-mail Aluno". $row["emailAluno"];
        echo "Data de Nascimento Aluno". $row["dataNascAluno"];
        echo "Rg Aluno". $row["rgAluno"];
        echo "Cpf Aluno". $row["cpfAluno"];
    }

    $stmt -> execute();

    header("location:apresentarAluno.php");
?>