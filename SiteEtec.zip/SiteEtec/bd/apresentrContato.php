<?php
    include("conexao.php");

    $nome = $_POST['txNome'];
    $email = $_POST['txEmail'];
    $assunto = $_POST['txAssunto'];
    $mensagem = $_POST['txMensagem'];

    $stmt = $pdo->prepare("select * from tbContato)");
    while($raw = $stmt->fetch()){
        echo "Id Contato". $row["idAdm"];
        echo "Nome". $row["nomeContato"];
        echo "E-mail". $row["emailContato"];
        echo "Assunto". $row["assuntoContato"];
        echo "Mensagem". $row["mensagemContato"];
    }

    $stmt -> execute();

    header("location:apresentarContato.php");
?>