<?php 
    include('conexão.php');

    $titulo = ;
    $descricao = ;
    $subtitulo =;

    $stmt = $pdo->prepare("insert into tbNoticia values(

                    null
                    '$titulo',
                    '$descricao',
                    '$subtitulo'
    )");
    $stmt -> execute();

?>