<?php
    include("conexao.php");

    $nome = $_POST['txNome'];
    $email = $_POST['txEmail'];
    $senha = $_POST['txSenha'];
    $nasc = $_POST['txDataNasc'];
    $rg = $_POST['txRg'];
    $cpf = $_POST['txCpf'];

    $stmt = $pdo->prepare("select * from tbAdm)");
    while($raw = $stmt->fetch()){
        echo "Id Administrador". $row["idAdm"];
        echo "Nome Administrador". $row["nomeAdm"];
        echo "E-mail Administrador". $row["emailAdm"];
        echo "Data de Nascimento Administrador". $row["dataNascAdm"];
        echo "Rg Administrador". $row["rgAdm"];
        echo "Cpf Administrador". $row["cpfAdm"];
    }

    $stmt -> execute();

    header("location:apresentarAdm.php");
?>