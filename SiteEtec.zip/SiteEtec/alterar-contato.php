<a href="apresentarContato.php"><img src="images/seta.png" width="35px" id=voltar></a>
<section>
<center>
    <fieldset>
        <div class="box">
            <form action="contato-alterar.php" method="post">
                <legend><b>Fórmulario</b></legend> 
                <div class="inputbox">
                <input type="hidden" name="txIdContato" value="<?php echo @$_GET['id']; ?>" />
                </div>
                <div class="inputbox">
                <input type="text" name="txNome" value="<?php echo @$_GET['nome']; ?>" placeholder="Nome" />
                    <label for="email">Nome</label>
                    <br><br>
                </div>
                <div class="inputbox">
                <input type="text" name="txEmail" value="<?php echo @$_GET['email']; ?>" placeholder="E-mail" />
                    <label for="CPF">E-mail</label>
                    <br><br>
                </div>
                <div class="inputbox">
                <input type="text" name="txAssunto" value="<?php echo @$_GET['assunto']; ?>" placeholder="Assunto" />
                    <label for="RG">Assunto</label>
                    <br><br>
                </div>
                <div class="inputbox">
                <input type="text" name="txMensagem" value="<?php echo @$_GET['msg']; ?>" placeholder="Mensagem" />
                    <label for="RG">Mensagem</label>
                    <br><br>
                </div>
                <br><br>
                <button type="submit">mandar</button>
            </form>
        </div>
    </fieldset>
</center>