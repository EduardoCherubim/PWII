<?php  
    $id = $_POST['txIdComentario'];
    $comentarios = $_POST['txComentarios'];
    
    include("conexao.php");

    $stmt = $pdo->prepare("
        update tbComentario set
            comentarios='$comentarios',
            where idComentario ='$id';
    ");	    
	$stmt ->execute();    

    header("location:consulta2.php");    
    
?>