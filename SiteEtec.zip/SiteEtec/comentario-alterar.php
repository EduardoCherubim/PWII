<?php  
    $id = $_POST['txIdComentario'];
    $comentarios = $_POST['txComentarios'];
    
    include("conexao.php");

    $stmt = $pdo->prepare("
        update tbcomentario set
            comentario='$comentarios'
            where idComentario ='$id';
    ");	    
	$stmt ->execute();    

    header("location:apresentarComentarios.php");    
    
?>