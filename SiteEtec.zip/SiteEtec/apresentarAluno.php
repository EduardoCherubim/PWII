<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/estilo.css">
</head>

<body>
    <center>
    <table border="1" class="table">
        <tr>
            <th>id Aluno</th>
            <th>Nome Aluno</th>
            <th>E-mail Aluno</th>
            <th>Senha Aluno</th>
            <th>Rg Aluno</th>
            <th>Cpf Aluno</th>
        </tr>
        <?php
            include("conexao.php");

            $stmt = $pdo->prepare("select * from tbaluno");
            $stmt -> execute();
            while($row = $stmt->fetch()){
                echo "
                <tr>
                   <td>".$row["idAluno"]."</td>
                   <td>".$row["nomeAluno"]."</td> 
                   <td>".$row["emailAluno"]."</td>
                   <td>".$row["senhaAluno"]."</td>
                   <td>".$row["rgAluno"]."</td>
                   <td>".$row["cpfAluno"]."</td>    
                </tr>";
            }

?>
    </table>
    </center>
</body>

</html>