<?php

    include("conexao.php");

    $Id = $_POST['txIdComentario'];
    $comentario = $_POST['txComentario'];
    
    $stmt = $pdo->prepare(" 
        UPDATE tbcomentario SET
        comentario = '$comentario',
        WHERE idComentario = '$Id';
     ");

    $stmt->execute();

    header("location:index.php");
    

?>